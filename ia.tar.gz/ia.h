#ifndef _IA_H
#define _IA_H

#include "utils.h"
#include "mapa.h"
#include "grafo.h"

int *Sequencia;

int resolve(tmapa *m);

#endif
